var u=(n,e)=>()=>(e||n((e={exports:{}}).exports,e),e.exports);var f=u(h=>{"use strict";Object.defineProperty(h,"__esModule",{value:!0});h.notifyMessage=void 0;async function C(n,e,t,r,i){let a=e.getNotifier(),o=a.getMessageBuilder();return o.setText(r),o.setRoom(n),i&&o.setThreadId(i),a.notifyUser(t,o.getMessage())}h.notifyMessage=C});var b=u(l=>{"use strict";Object.defineProperty(l,"__esModule",{value:!0});l.createTextCompletion=void 0;var T=f();async function _(n,e,t,r,i,a,o){let s=await n.getAccessors().environmentReader.getSettings().getValueById("model"),m=`http://${s}/v1`,p={model:s,messages:[{role:"system",content:a}],temperature:0},d=await i.post(m+"/chat/completions",{headers:{"Content-Type":"application/json"},content:JSON.stringify(p)});if(!d.content)throw await(0,T.notifyMessage)(e,t,r,"Something is wrong with AI. Please try again later",o),new Error("Something is wrong with AI. Please try again later");return JSON.parse(d.content).choices[0].message.content}l.createTextCompletion=_});var I=u(c=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0});c.createSummaryPrompt=void 0;var j=`Summarize the following dialogue using 1-3 short and simple sentences. Use as fewer words as possible. Mention the names of specific persons.

Dialogue: ###
Tim: Hi, what's up? Kim: Bad mood tbh, I was going to do lots of stuff but ended up procrastinating Tim: What did you plan on doing? Kim: Oh you know, uni stuff and unfucking my room Kim: Maybe tomorrow I'll move my ass and do everything Kim: We were going to defrost a fridge so instead of shopping I'll eat some defrosted veggies Tim: For doing stuff I recommend Pomodoro technique where u use breaks for doing chores Tim: It really helps Kim: thanks, maybe I'll do that Tim: I also like using post-its in kaban style
###

Summary: Kim may try the pomodoro technique recommended by Tim to get more stuff done.

---

Summarize the following dialogue using 1-3 short and simple sentences. Use as fewer words as possible. Mention the names of specific persons.

Dialogue: ###
John: Ave. Was there any homework for tomorrow? Cassandra: hello :D Of course, as always :D John: What exactly? Cassandra: I'm not sure so I'll check it for you in 20minutes. John: Cool, thanks. Sorry I couldn't be there, but I was busy as fuck...my stupid boss as always was trying to piss me off Cassandra: No problem, what did he do this time? John: Nothing special, just the same as always, treating us like children, commanding to do this and that... Cassandra: sorry to hear that. but why don't you just go to your chief and tell him everything? John: I would, but I don't have any support from others, they are like goddamn pupets and pretend that everything's fine...I'm not gonna fix everything for everyone Cassandra: I understand...Nevertheless, just try to ignore him. I know it might sound ridiculous as fuck, but sometimes there's nothing more you can do. John: yeah I know...maybe some beer this week? Cassandra: Sure, but I got some time after classes only...this week is gonna be busy John: no problem, I can drive you home and we can go to some bar or whatever. Cassandra: cool. ok, I got this homework. it's page 15 ex. 2 and 3, I also asked the others to study another chapter, especially the vocabulary from the very first pages. Just read it. John: gosh...I don't know if I'm smart enough to do it :'D Cassandra: you are, don't worry :P Just circle all the words you don't know and we'll continue on Monday. John: ok...then I'll try my best :D Cassandra: sure, if you will have any questions just either text or call me and I'll help you. John: I hope I won't have to waste your time xD Cassandra: you're not wasting my time, I'm your teacher, I'm here to help. This is what I get money for, also :P John: just kidding :D ok, so i guess we'll stay in touch then Cassandra: sure, have a nice evening :D John: you too, se ya Cassandra: Byeeeee
###

Summary: John didn't show up for class due to some work issues with his boss. Cassandra, his teacher told him which exercises to do, and which chapter to study. They are going to meet up for a beer sometime this week after class.

---

Summarize the following dialogue using 1-3 short and simple sentences. Use as fewer words as possible. Mention the names of specific persons.

Dialogue: ###
Leon: did you find the job yet? Arthur: no bro, still unemployed :D Leon: hahaha, LIVING LIFE Arthur: i love it, waking up at noon, watching sports - what else could a man want? Leon: a paycheck? ;) Arthur: don't be mean... Leon: but seriously, my mate has an offer as a junior project manager at his company, are you interested? Arthur: sure thing, do you have any details? Leon: <file_photo> Arthur: that actually looks nice, should I reach out directly to your friend or just apply to this email address from the screenshot? Leon: it's his email, you can send your resume directly and I will mention to him who you are :)
###

Summary: Arthur is still unemployed. Leon sends him a job offer for junior project manager position. Arthur is interested.

---

Summarize the following dialogue using 1-3 short and simple sentences. Use as fewer words as possible. Mention the names of specific persons.

Dialogue: ###
{dialogue}
###

Summary: `;function P(n){return j.replace("{dialogue}",n)}c.createSummaryPrompt=P});var k=u(y=>{"use strict";Object.defineProperty(y,"__esModule",{value:!0});y.SummarizeCommand=void 0;var w=f(),x=b(),A=I(),v=class{constructor(e){this.command="summarize-thread",this.i18nParamsExample="Summarize messages in a thread",this.i18nDescription="",this.providesPreview=!1,this.app=e}async executor(e,t,r,i){let a=e.getSender(),o=e.getRoom(),s=e.getThreadId();if(!s)throw await(0,w.notifyMessage)(o,t,a,"You can only call /summarize-thread in a thread"),new Error("You can only call /summarize-thread in a thread");let m=await this.getThreadMessages(o,t,a,s),p=(0,A.createSummaryPrompt)(m),d=await(0,x.createTextCompletion)(this.app,o,t,a,i,p,s);await(0,w.notifyMessage)(o,t,a,d,s)}async getThreadMessages(e,t,r,i){let o=await t.getThreadReader().getThreadById(i);if(!o)throw await(0,w.notifyMessage)(e,t,r,"Thread not found"),new Error("Thread not found");let s=[];for(let m of o)m.text&&s.push(`${m.sender.name}: ${m.text}`);return s.shift(),s.join(`
`)}};y.SummarizeCommand=v});var S=u(g=>{"use strict";Object.defineProperty(g,"__esModule",{value:!0});g.settings=void 0;var J=require("@rocket.chat/apps-engine/definition/settings");g.settings=[{id:"model",i18nLabel:"Model selection",i18nDescription:"AI model to use for summarization.",type:J.SettingType.SELECT,values:[{key:"llama3-70b",i18nLabel:"Llama3 70B"},{key:"mistral-7b",i18nLabel:"Mistral 7B"}],required:!0,public:!0,packageValue:"llama3-70b"}]});"use strict";Object.defineProperty(exports,"__esModule",{value:!0});exports.ThreadSummarizerApp=void 0;var z=require("@rocket.chat/apps-engine/definition/App"),D=k(),L=S(),M=class extends z.App{constructor(e,t,r){super(e,t,r)}async extendConfiguration(e){await Promise.all([...L.settings.map(t=>e.settings.provideSetting(t)),e.slashCommands.provideSlashCommand(new D.SummarizeCommand(this))])}};exports.ThreadSummarizerApp=M;
